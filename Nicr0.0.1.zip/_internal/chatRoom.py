import threading, tkinter, client, socket
from tkinter import scrolledtext, simpledialog
class ChatRoom:
    def __init__(self, code, name, sock):
        self.run_event = threading.Event()
        self.run_event.set()
        self.code = code.zfill(4)
        self.name = name
        self.sock = sock
        print("Local Chat Room Created")
        gui_thread = threading.Thread(target=self.gui_thread)
        gui_thread.start()

    def gui_thread(self):
        self.win = tkinter.Tk()
        self.win.configure(bg="lightgray")
        self.win.title = "Nicr"
        self.chat_label = tkinter.Label(self.win, text="Chat:", bg="lightgray")
        self.chat_label.config(font=("Arial", 12))
        self.chat_label.pack(padx=20, pady=5)

        self.text_area = tkinter.scrolledtext.ScrolledText(self.win)
        self.text_area.pack(padx=20, pady=5)
        self.text_area.config(state='disabled')

        self.msg_label = tkinter.Label(self.win, text="Message:", bg="lightgray")
        self.msg_label.config(font=("Arial", 12))
        self.msg_label.pack(padx=20, pady=5)

        self.inputArea = tkinter.Text(self.win, height=3)
        self.inputArea.pack(padx=20, pady=5)

        self.send_button = tkinter.Button(self.win, text="Send", command=self.write)
        self.send_button.config(font=("Arial", 12))
        self.send_button.pack(padx=20, pady=5)

        self.win.protocol("WM_DELETE_WINDOW", self.stop)
        self.win.mainloop()
    def receive(self, msg):
        print("Attempting to load message")
        self.text_area.config(state='normal')
        self.text_area.insert('end', msg)
        self.text_area.yview('end')
        self.text_area.config(state='disabled')
        print(msg)
    def write(self):
        self.sock.send(f"c{self.code}{self.name}: {self.inputArea.get('1.0', 'end')}".encode('utf-8'))
        self.inputArea.delete('1.0', 'end')

    def stop(self):
        self.win.destroy()

