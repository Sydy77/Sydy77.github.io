import socket, threading, tkinter, tkinter.scrolledtext, pickle, os, chatRoom
from tkinter import simpledialog, ttk
class Client:
    def __init__(self, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((pickle.load(open("data.dat", "rb")), port))
        self.name = os.getlogin()
        self.running = True
        self.gui_done = False
        gui_thread = threading.Thread(target=self.gui_loop)
        receive_thread = threading.Thread(target=self.receive)
        gui_thread.start()
        receive_thread.start()
        self.currentChatRooms = {}


    def gui_loop(self):
        self.win = tkinter.Tk()
        self.win.configure(bg="lightgray")
        self.win.title = "Nicr"
        self.tabs = ttk.Notebook(self.win)
        self.tab1 = ttk.Frame(self.tabs)
        self.connectInArea = tkinter.Text(self.tab1, height=3)
        self.connectInArea.pack(padx=20, pady=5)
        self.connectButton = tkinter.Button(self.tab1, text="Connect", command=self.createRoom)
        self.connectButton.config(font=("Arial", 12))
        self.connectButton.pack(padx=20, pady=5)
        self.tabs.add(self.tab1, text="Home")
        self.tabs.pack(expand=1, fill="both")

        self.gui_done = True
        self.win.protocol("WM_DELETE_WINDOW", self.stop)
        self.win.mainloop()
    def stop(self):
        self.running = False
        self.win.destroy()
        self.sock.close()
        exit(0)
    def createRoom(self):
        message = f"/OP& {self.connectInArea.get('1.0', 'end')}"
        self.sock.send(message.encode('utf-8'))
        self.connectInArea.delete('1.0', 'end')

    def receive(self):
        while self.running:
            try:
                message = self.sock.recv(1024).decode('utf-8')
                print(message)
                if message == "--NAME*&&^%$$)--":
                    self.sock.send(self.name.encode('utf-8'))
                elif message[0] == 'g':
                    code = message[1:]
                    self.currentChatRooms[code] = chatRoom.ChatRoom(code, self.name, self.sock)
                    print("Local Chat room requested")
                elif message == "connected?":
                    pass
                elif message[0] == 'c':
                    try:
                        print("Private message received")
                        print(self.currentChatRooms.items())
                        on = self.currentChatRooms[str(int(message[1:5]))].receive(message[5:])
                        if not on:
                            del self.currentChatRooms[str(int(message[1:5]))]
                    except:
                        pass

            except ConnectionAbortedError:
                break
            except:
                self.sock.close()
                break
    def send(self, msg):
        self.sock.send(msg.encode('utf-8'))

